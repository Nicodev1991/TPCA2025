#!/bin/bash

# Script: backup_full.sh
# Descripción: Script para realizar backups comprimidos
# Nombre de fecha ANSI (YYYYMMDD), validando disponibilidad
# Uso: ./backup_full.sh /ruta/origen /ruta/destino. Acepta parámetros y opción -help.

# Paso 1: Función de ayuda
mostrar_ayuda() {
    echo "Uso: $0 ORIGEN DESTINO"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "Este script realiza un backup comprimido del directorio ORIGEN"
    echo "y lo guarda en DESTINO con formato: nombre_bkp_YYYYMMDD.tar.gz"
    echo "Opciones:"
    echo "   -help        Mostrar esta ayuda"
    exit 0
}

# Paso 2: Verificar si se pidió ayuda
if [[ "$1" == "-help" ]]; then
    mostrar_ayuda
fi

# Paso 3: Validar argumentos
if [[ -z "$1" || -z "$2" ]]; then
    echo "Error: Debes especificar el directorio origen y destino."
    echo "Usá -help para más información."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Paso 4: Validar que existan origen y destino
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe."
    exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El directorio de destino '$DESTINO' no existe."
    exit 1
fi

# Paso 5: Generar nombre del archivo con fecha en formato YYYYMMDD
FECHA=$(date +%Y%m%d)
NOMBRE_ORIGEN=$(basename "$ORIGEN")
ARCHIVO="$DESTINO/${NOMBRE_ORIGEN}_bkp_${FECHA}.tar.gz"

# Paso 6: Realizar el backup
tar -czf "$ARCHIVO" "$ORIGEN" 2>/dev/null

# Paso 7: Verificar si el backup se realizó correctamente
if [[ $? -eq 0 ]]; then
    echo "Backup exitoso: $ARCHIVO"
else
    echo "Error al generar el backup."
    exit 1
fi

